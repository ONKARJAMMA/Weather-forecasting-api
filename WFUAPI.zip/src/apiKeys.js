// Visit https://api.openweathermap.org & then signup to get our API keys for free
module.exports = {
  key: "a57a760b0956e0f0284de69af7f403cd",
  base: "https://api.openweathermap.org/data/2.5/",
};
// here we are used the api which connects us to the real time temperature forecast
// the api is from open weather map 
// a57a760b0956e0f0284de69af7f403cd this is the key of the api